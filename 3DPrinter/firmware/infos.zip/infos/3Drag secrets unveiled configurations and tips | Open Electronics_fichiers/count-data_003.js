var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"{num} Comments","one":"1 Comment"}},"counts":[{"uid":10,"comments":2},{"uid":11,"comments":180},{"uid":12,"comments":111},{"uid":13,"comments":98},{"uid":14,"comments":75},{"uid":15,"comments":53},{"uid":16,"comments":0},{"uid":17,"comments":0},{"uid":18,"comments":0},{"uid":19,"comments":0}]});
}