var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"{num} Comments","one":"1 Comment"}},"counts":[{"uid":0,"comments":0},{"uid":1,"comments":0},{"uid":2,"comments":0},{"uid":3,"comments":0},{"uid":4,"comments":0},{"uid":5,"comments":0},{"uid":6,"comments":4},{"uid":7,"comments":2},{"uid":8,"comments":0},{"uid":9,"comments":0}]});
}